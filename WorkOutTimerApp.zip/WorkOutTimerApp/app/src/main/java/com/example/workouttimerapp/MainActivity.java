package com.example.workouttimerapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Chronometer workoutTimer;
    private long pauseSet;
    private boolean running;
    String RUNNING;
    TextView displayMessage;
    EditText workoutType;
    String TIMER;
    Long time;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        workoutTimer = findViewById(R.id.workoutTimer);
        displayMessage = findViewById(R.id.displayMessage);
        workoutType = findViewById(R.id.workoutType);

        if (savedInstanceState != null) {
            running = savedInstanceState.getBoolean(RUNNING);
            time = savedInstanceState.getLong(TIMER);
            workoutTimer.setBase(time);
            if(running)
            {
                workoutTimer.setBase(SystemClock.elapsedRealtime() + time - pauseSet);
            }
            workoutTimer.start();
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean(RUNNING, running);
        outState.putLong(TIMER, workoutTimer.getBase());
    }


    public void startClick(View v) {
        if (!running) {
            workoutTimer.setBase(SystemClock.elapsedRealtime() - pauseSet);
            workoutTimer.start();
            running = true;
        }
    }

    public void pauseClick(View v) {
        if (running) {
            workoutTimer.stop();
            pauseSet = SystemClock.elapsedRealtime() - workoutTimer.getBase();
            running = false;
        }
    }

    public void stopClick(View v) {
        displayMessage.setText("You spent " + workoutTimer.getText().toString() + " on " + workoutType.getText().toString() + " last time.");
        workoutTimer.setBase(SystemClock.elapsedRealtime());
        workoutTimer.stop();
        workoutType.setText("");
        pauseSet = 0;
        running = false;
    }
}

